# how to execute a shell program?
# 1. bash <filename>

# shell program
#	has # of commands of the shell
#	case sensitive
echo "ondu"
pwd
echo "eradu"
ls
echo "mooru"

