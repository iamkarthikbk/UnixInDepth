# 3. source <filename>
#	or
#	 . <filename>
#	requirement : modify the environment of the current shell
#	use sourcing
#	.   is a comamnd
a=five
echo "a : $a"

