#! /bin/bash
# how to execute a shell program?
# 2../<filename>
#	file should have execute permission
#	first line : !# line

# shell program
#	has # of commands of the shell
#	case sensitive
echo "ondu"
pwd
echo "eradu"
ls
echo "mooru"
