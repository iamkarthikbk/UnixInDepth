echo "enter some input"
# first input goes to a; second to b; rest to c
read a b c
echo "a : $a"
echo "b : $b"
echo "c : $c"

