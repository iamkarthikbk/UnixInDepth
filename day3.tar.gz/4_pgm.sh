# 4. using exec
#	exec <./filename>
#	file should have execute permission
echo "idu"
a="nooru"
echo "aaru"
