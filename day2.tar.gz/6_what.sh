echo "this is a shell command"
