#! /home/nsk/anaconda3/bin/python
print("this is python")

